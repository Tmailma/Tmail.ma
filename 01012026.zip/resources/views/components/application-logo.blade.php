<img src="{{ asset("images/backend-logo-light.png") }}" class="dark:hidden max-w-32" alt="TMail" />
<img src="{{ asset("images/backend-logo-dark.png") }}" class="hidden dark:block max-w-32" alt="TMail" />
