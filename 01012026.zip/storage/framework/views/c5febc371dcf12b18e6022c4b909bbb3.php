<img src="<?php echo e(asset("images/backend-logo-light.png")); ?>" class="dark:hidden max-w-32" alt="TMail" />
<img src="<?php echo e(asset("images/backend-logo-dark.png")); ?>" class="hidden dark:block max-w-32" alt="TMail" />
<?php /**PATH /home/tmail/public_html/resources/views/components/application-mark.blade.php ENDPATH**/ ?>