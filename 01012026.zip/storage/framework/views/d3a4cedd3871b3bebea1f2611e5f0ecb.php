<div <?php echo $attributes->merge(["class" => "bg-white dark:bg-gray-800 overflow-hidden shadow border dark:border-gray-700 rounded-2xl"]); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/tmail/public_html/resources/views/components/card.blade.php ENDPATH**/ ?>